package cc.ccwu.signalfeed

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun GlobalImageBackdrop() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("global_background", 0) }
    var uri by remember { mutableStateOf(prefs.getString("image_uri", null)?.let(Uri::parse)) }
    val enabled = LocalFeatures.current.enabled(Feature.GLOBAL_BACKGROUND)
    val bitmap = remember(uri, enabled) {
        if (!enabled || uri == null) null else runCatching {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri!!).use { BitmapFactory.decodeStream(it, null, bounds) }
            val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 1800)
            resolver.openInputStream(uri!!).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
        }.getOrNull()
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = if (bitmap == null) 1f else .72f)))
    }
}

@Composable
internal fun GlobalBackdropSettings() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("global_background", 0) }
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf(prefs.getString("image_uri", null)?.let(Uri::parse)) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) {
                context.contentResolver.takePersistableUriPermission(selected, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } }
            prefs.edit().putString("image_uri", selected.toString()).apply()
            uri = selected
        }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text("全局背景图片", style = MaterialTheme.typography.titleMedium)
        Text(if (uri == null) "尚未选择图片" else "已设置图片，可更换或移除", style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { picker.launch(arrayOf("image/*")) }) { Text(if (uri == null) "导入图片" else "更换图片") }
            if (uri != null) TextButton(onClick = { prefs.edit().remove("image_uri").apply(); uri = null }) { Text("移除") }
        }
    }
}